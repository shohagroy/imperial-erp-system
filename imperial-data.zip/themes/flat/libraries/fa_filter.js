if($(window).width() < 681) {
	$(".overduefg").hide();
}