<?php 
/****************************************
/*  Author  : Kvvaradha
/*  Module  : SMS Gateway
/*  E-mail  : admin@kvcodes.com
/*  Version : 1.0
/*  Http    : www.kvcodes.com
*****************************************/
// $path_to_root = '../../..';

class Kvcodes_sms_gateway {

    public function __construct() {

    }
    public function sendsms($phone_no, $msg) {
        return true;
    }
}